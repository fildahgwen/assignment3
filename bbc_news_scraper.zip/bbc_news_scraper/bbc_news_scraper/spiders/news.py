
import scrapy

class NewsSpider(scrapy.Spider):
    name = 'news'
    start_urls = [
        'https://www.bbc.com/business',
        'https://www.bbc.com/news/world',
        'https://www.bbc.com/sport',
        'https://www.bbc.com/culture/entertainment-news'
    ]

    def parse(self, response):
        category_map = {
            'https://www.bbc.com/business': 'Business',
            'https://www.bbc.com/news/world': 'Politics',
            'https://www.bbc.com/sport': 'Sports',
            'https://www.bbc.com/culture/entertainment-news': 'Entertainment'
        }

        category = category_map.get(response.url)

        for article in response.css('.gel-wrap.l-grid__item article'):
            yield {
                'title': article.css('h3::text').get(),
                'category': category,
                'text': ' '.join(article.css('.sc-b77c8bb-0 kqIEbK::text').getall())  # Adjust selector based on actual text selector
            }
